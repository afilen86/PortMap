Port Map — Workspace Orbit Preview 0.1.0

GET STARTED ON YOUR MAC
1. Extract this ZIP (double-click it in Finder).
2. Double-click "Port Map Orbit.html".
3. Choose Light, Dark, or System at the top.

No installation, server, internet connection, Node, or Swift is required.
The HTML file contains its scripts, styles, and device imagery.

LIGHT: Clay Studio — warm terracotta/olive, compact peripherals, a larger Mac.
DARK: After Hours — plum/rose, with larger device portraits.
SYSTEM: follows your Mac/browser appearance unless you choose another mode.
The appearance preference is remembered when browser storage is available.

Click any device to trace its complete route. "Locate a device" selects without
hiding any images. "Trace only" emphasizes its cables. "Pause flow" stops motion.
All 19 image cards stay visible at typical desktop window sizes.

THIS IS A BROWSER PREVIEW, NOT A NATIVE MAC APP INSTALLER.
It displays a saved setup. It does not scan your Mac or report live traffic.
Animated paths illustrate signal/data direction. The same display name appears
on USB-C and HDMI; these are shown as separate reported paths, not confirmed
unique displays. Representative artwork is marked ~= (shown as ≈ in the UI),
and manually entered connections are marked M. See IMAGERY-NOTICES.txt.

Source and developer instructions:
https://github.com/afilen86/PortMap

To verify the HTML file, compare its SHA-256 with entryPointSha256 in release.json:
  shasum -a 256 "Port Map Orbit.html"
